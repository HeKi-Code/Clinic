
<?php
session_start();
require 'dbcon.php';

if(isset($_POST['delete_patient']))
{


    $patient_id = mysqli_real_escape_string($con, $_POST['delete_patient']);

    $query = "DELETE FROM healthrecord WHERE id='$patient_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Patient Record Moved to Archive Successfully";
        header("Location: ../health/recordtable.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Patient Record Not Moved";
        header("Location: ../health/recordtable.php");
        exit(0);
    }
}

if(isset($_POST['delete_info']))
{
    $patient_id = mysqli_real_escape_string($con, $_POST['delete_info']);

    $query = "DELETE FROM info WHERE id='$patient_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Patient Information Moved to Archive Successfully";
        header("Location: ../info/infotable.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Patient Information Not Moved";
        header("Location: ../info/infotable.php");
        exit(0);
    }
}
 
// delete staff

if(isset($_POST['delete_staff']))
{


    $staff_id = mysqli_real_escape_string($con, $_POST['delete_staff']);

    $query = "DELETE FROM staff WHERE id='$staff_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Staff Account Deleted";
        header("Location: ../staff/staff.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Staff Account Was not Deleted";
        header("Location: ../staff/staff.php");
        exit(0);
    }
}

if(isset($_POST['update_record']))
{
    $patient_id = mysqli_real_escape_string($con, $_POST['patient_id']);

   
    $fname = mysqli_real_escape_string($con, $_POST['fname']);
    $bday = mysqli_real_escape_string($con, $_POST['bday']);
    $age = mysqli_real_escape_string($con, $_POST['age']);
    $gender = mysqli_real_escape_string($con, $_POST['gender']);
    $height = mysqli_real_escape_string($con, $_POST['height']);
    $weight = mysqli_real_escape_string($con, $_POST['weight']);
    $cellno = mysqli_real_escape_string($con, $_POST['cellno']);
    $occupation = mysqli_real_escape_string($con, $_POST['occupation']);
    $officeadd = mysqli_real_escape_string($con, $_POST['officeadd']);
    $homeadd = mysqli_real_escape_string($con, $_POST['homeadd']);
    $homeno = mysqli_real_escape_string($con, $_POST['homeno']);
    $guardian = mysqli_real_escape_string($con, $_POST['guardian']);
    $gcellno = mysqli_real_escape_string($con, $_POST['gcellno']);
    $complaint = mysqli_real_escape_string($con, $_POST['complaint']);
    $physician = mysqli_real_escape_string($con, $_POST['physician']);
    $referred = mysqli_real_escape_string($con, $_POST['referred']);
    
    $query = "UPDATE healthrecord SET fname='$fname', bday='$bday', age='$age', gender='$gender',height='$height', weight='$weight', 
    cellno='$cellno', occupation='$occupation', officeadd='$officeadd', homeadd='$homeadd', homeno='$homeno', guardian='$guardian',
    gcellno='$gcellno', complaint='$complaint' , physician='$physician', referred='$referred' WHERE id='$patient_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Student Updated Successfully";
        header("Location: ../health/recordtable.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Updated";
        header("Location: ../health/recordtable.php");
        exit(0);
    }

}

if(isset($_POST['update_info']))
{
    $patient_id = mysqli_real_escape_string($con, $_POST['patient_id']);

   
    $fname = mysqli_real_escape_string($con, $_POST['fname']);
    $age = mysqli_real_escape_string($con, $_POST['age']);
    $bday = mysqli_real_escape_string($con, $_POST['bday']);
    $cellno = mysqli_real_escape_string($con, $_POST['cellno']);
    $homeadd = mysqli_real_escape_string($con, $_POST['homeadd']);
    $occupation = mysqli_real_escape_string($con, $_POST['occupation']);
    $cellno = mysqli_real_escape_string($con, $_POST['cellno']);
    $hname = mysqli_real_escape_string($con, $_POST['hname']);
    $hage = mysqli_real_escape_string($con, $_POST['hage']);
    $dob = mysqli_real_escape_string($con, $_POST['dob']);
    $hoccupation = mysqli_real_escape_string($con, $_POST['hoccupation']);
    $hstatus = mysqli_real_escape_string($con, $_POST['hstatus']);
    $obs1 = mysqli_real_escape_string($con, $_POST['obs1']);
    $obs2 = mysqli_real_escape_string($con, $_POST['obs2']);
    $obs3 = mysqli_real_escape_string($con, $_POST['obs3']);
    $obs4 = mysqli_real_escape_string($con, $_POST['obs4']);
    $medh1 = mysqli_real_escape_string($con, $_POST['medh1']);
    $medh2 = mysqli_real_escape_string($con, $_POST['medh2']);
    $medh3 = mysqli_real_escape_string($con, $_POST['medh3']);
    $medh4 = mysqli_real_escape_string($con, $_POST['medh4']);
    $medh5 = mysqli_real_escape_string($con, $_POST['medh5']);
    $medh6 = mysqli_real_escape_string($con, $_POST['medh6']);
    $lmp = mysqli_real_escape_string($con, $_POST['lmp']);
    $edd = mysqli_real_escape_string($con, $_POST['edd']);
    $date = mysqli_real_escape_string($con, $_POST['date']);
    $aog = mysqli_real_escape_string($con, $_POST['aog']);
    $bp = mysqli_real_escape_string($con, $_POST['bp']);
    $wt = mysqli_real_escape_string($con, $_POST['wt']);
    $fh = mysqli_real_escape_string($con, $_POST['fh']);
    $fht = mysqli_real_escape_string($con, $_POST['fht']);
    $loc = mysqli_real_escape_string($con, $_POST['loc']);
    $pres = mysqli_real_escape_string($con, $_POST['pres']);
    $tcb = mysqli_real_escape_string($con, $_POST['tcb']);
    $signature = mysqli_real_escape_string($con, $_POST['signature']);
    
    $query = "UPDATE info SET fname='$fname', age='$age',bday='$bday',cellno='$cellno',homeadd='$homeadd',occupation='$occupation',
    hname='$hname',hage='$hage',dob='$dob',hoccupation='$hoccupation',hstatus='$hstatus',obs1='$obs1',obs2='$obs2',obs3='$obs3',obs4='$obs4',medh1='$medh1',medh2='$medh2',
    medh3='$medh3',medh4='$medh4',medh5='$medh5',medh6='$medh6',lmp='$lmp',edd='$edd',date='$date',aog='$aog',bp='$bp',wt='$wt',fh='$fh',fht='$fht',loc='$loc'
    ,pres='$pres',tcb='$tcb',signature='$signature' WHERE id='$patient_id' ";
    $query_run = mysqli_query($con, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Student Updated Successfully";
        header("Location: ../info/infotable.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Updated";
        header("Location: ../info/infotable.php");
        exit(0);
    }

}
// staff account 
if(isset($_POST['save_staff']))
{
    $username = mysqli_real_escape_string($con, $_POST['username']);
    $password = mysqli_real_escape_string($con, $_POST['password']);
 
    
    $query = "INSERT INTO staff (username, password)
     VALUES ('$username','$password')";

        $query_run = mysqli_query($con, $query);
        if($query_run)
    
        {
            
            $_SESSION['message'] = "Staff Account Created Successfully";
            header("Location: ../staff/addstaff.php");
            exit(0);
        }
        else
        {
            $_SESSION['message'] = "Staff Account Was not Created";
            header("Location:../staff/addstaff.php");
            exit(0);
        }

}
// save health record and info
if(isset($_POST['save_record']))
{
    $fname = mysqli_real_escape_string($con, $_POST['fname']);
    $bday = mysqli_real_escape_string($con, $_POST['bday']);
    $age = mysqli_real_escape_string($con, $_POST['age']);
    $gender = mysqli_real_escape_string($con, $_POST['gender']);
    $height = mysqli_real_escape_string($con, $_POST['height']);
    $weight = mysqli_real_escape_string($con, $_POST['weight']);
    $cellno = mysqli_real_escape_string($con, $_POST['cellno']);
    $occupation = mysqli_real_escape_string($con, $_POST['occupation']);
    $officeadd = mysqli_real_escape_string($con, $_POST['officeadd']);
    $homeadd = mysqli_real_escape_string($con, $_POST['homeadd']);
    $homeno = mysqli_real_escape_string($con, $_POST['homeno']);
    $guardian = mysqli_real_escape_string($con, $_POST['guardian']);
    $gcellno = mysqli_real_escape_string($con, $_POST['gcellno']);
    $complaint = mysqli_real_escape_string($con, $_POST['complaint']);
    $physician = mysqli_real_escape_string($con, $_POST['physician']);
    $referred = mysqli_real_escape_string($con, $_POST['referred']);
    $date = mysqli_real_escape_string($con, $_POST['date']);
    $exam = mysqli_real_escape_string($con, $_POST['exam']);
    $notes = mysqli_real_escape_string($con, $_POST['notes']);
    
    $query = "INSERT INTO healthrecord (fname,bday,age,gender,height,weight,cellno,occupation,officeadd,
    homeadd,homeno,guardian,gcellno,complaint,physician,referred,date,exam,notes)
     VALUES ('$fname','$bday','$age','$gender','$height','$weight', 
    '$cellno', '$occupation','$officeadd','$homeadd','$homeno','$guardian','$gcellno','$complaint',
    '$physician','$referred','$date','$exam','$notes')";

        $query_run = mysqli_query($con, $query);
        if($query_run)
    
        {
            
            $_SESSION['message'] = "Patient Health Record Created Successfully";
            header("Location: admin/health/addrecord.php");
            exit(0);
        }
        else
        {
            $_SESSION['message'] = "Patient Health Record Not Created";
            header("Location: admin/health/addrecord.php");
            exit(0);
        }

}



// info datas
if(isset($_POST['save_info']))
{
    $fname = mysqli_real_escape_string($con, $_POST['fname']);
    $age = mysqli_real_escape_string($con, $_POST['age']);
    $bday = mysqli_real_escape_string($con, $_POST['bday']);
    $cellno = mysqli_real_escape_string($con, $_POST['cellno']);
    $homeadd = mysqli_real_escape_string($con, $_POST['homeadd']);
    $occupation = mysqli_real_escape_string($con, $_POST['occupation']);
    $cellno = mysqli_real_escape_string($con, $_POST['cellno']);
    $hname = mysqli_real_escape_string($con, $_POST['hname']);
    $hage = mysqli_real_escape_string($con, $_POST['hage']);
    $dob = mysqli_real_escape_string($con, $_POST['dob']);
    $hoccupation = mysqli_real_escape_string($con, $_POST['hoccupation']);
    $hstatus = mysqli_real_escape_string($con, $_POST['hstatus']);
    $obs1 = mysqli_real_escape_string($con, $_POST['obs1']);
    $obs2 = mysqli_real_escape_string($con, $_POST['obs2']);
    $obs3 = mysqli_real_escape_string($con, $_POST['obs3']);
    $obs4 = mysqli_real_escape_string($con, $_POST['obs4']);
    $medh1 = mysqli_real_escape_string($con, $_POST['medh1']);
    $medh2 = mysqli_real_escape_string($con, $_POST['medh2']);
    $medh3 = mysqli_real_escape_string($con, $_POST['medh3']);
    $medh4 = mysqli_real_escape_string($con, $_POST['medh4']);
    $medh5 = mysqli_real_escape_string($con, $_POST['medh5']);
    $medh6 = mysqli_real_escape_string($con, $_POST['medh6']);
    $lmp = mysqli_real_escape_string($con, $_POST['lmp']);
    $edd = mysqli_real_escape_string($con, $_POST['edd']);
    $date = mysqli_real_escape_string($con, $_POST['date']);
    $aog = mysqli_real_escape_string($con, $_POST['aog']);
    $bp = mysqli_real_escape_string($con, $_POST['bp']);
    $wt = mysqli_real_escape_string($con, $_POST['wt']);
    $fh = mysqli_real_escape_string($con, $_POST['fh']);
    $fht = mysqli_real_escape_string($con, $_POST['fht']);
    $loc = mysqli_real_escape_string($con, $_POST['loc']);
    $pres = mysqli_real_escape_string($con, $_POST['pres']);
    $tcb = mysqli_real_escape_string($con, $_POST['tcb']);
    $signature = mysqli_real_escape_string($con, $_POST['signature']);
    
    $query = "INSERT INTO info(fname,age,bday,cellno,homeadd,occupation,hname,hage,dob,hoccupation,hstatus,obs1,obs2,obs3,obs4,medh1,medh2,medh3,medh4,medh5,medh6,lmp,edd,date,aog,bp,wt,fh,fht,loc,pres,tcb,signature) 
                     VALUES  ('$fname','$age','$bday','$cellno', '$homeadd','$occupation','$hname','$hage', '$dob','$hoccupation','$hstatus','$obs1','$obs2','$obs3','$obs4','$medh1','$medh2','$medh3','$medh4','$medh5','$medh6','$lmp','$edd','$date','$aog','$bp','$wt','$fh','$fht','$loc','$pres','$tcb','$signature')";

     $query_run = mysqli_query($con, $query);
        if($query_run)
    
        {
            
            $_SESSION['message'] = "Patient Health Record Created Successfully";
            header("Location: ../info/addinfo.php");
            exit(0);
        }
        else
        {
            $_SESSION['message'] = "Patient Health Record Not Created";
            header("Location: ../info/addinfo.php");
            exit(0);
        }

}

?>