<?php
require '..//db/dbcon.php';
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="shortcut icon" href="assets/img/a.png" type="image/x-icon">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}
#Button{
    display: block;
  }
 
  @media print {
    #Button {
      display: none;
    }
  }

.container a {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 45px;
    width: 100%;
    color: #fff;
    border-radius: 5px;
    margin: 25px 0;
    background-color: #4070f4;
    transition: all 0.3s linear;
    cursor: pointer;
}
  .home-section .health-content{
    padding-top: 200px;
  }

.container{
    position: relative;
    max-width: 100%;
    width: 98%;
    border-radius: 6px;
    padding: 30px;
    margin-left: 15px;
    background-color: #fff;
    box-shadow: 0 5px 10px rgba(0,0,0,0.1);
}
.container h3{
    position: relative;
    font-size: 20px;
    font-weight: 600;
    color: #333;
    text-align: center;
    width: calc(100% / 1 - 15px);
}


.container form{
    position: relative;
    margin-top: 16px;
    min-height: 1350px;
    background-color: #fff;
    overflow: hidden;
}
.container form .form{
    position: absolute;
    background-color: #fff;
    transition: 0.3s ease;
}
.container form .form.second{
    opacity: 0;
    pointer-events: none;
    transform: translateX(100%);
}
form.secActive .form.second{
    opacity: 1;
    pointer-events: auto;
    transform: translateX(0);
}
form.secActive .form.first{
    opacity: 0;
    pointer-events: none;
    transform: translateX(-100%);
}
.container form .title{
    display: block;
    margin-bottom: 8px;
    font-size: 16px;
    font-weight: 500;
    margin: 6px 0;
    color: #333;
}
.container form .fields{
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
}
form .fields .input-field{
    display: flex;
    width: calc(100% / 1 - 15px);
    flex-direction: column;
    margin: 4px 0;
}
.input-field label{
    font-size: 12px;
    font-weight: 500;
    color: #2e2e2e;
}
.input-field input, select{
    outline: none;
    font-size: 14px;
    font-weight: 400;
    color: #333;
    border-radius: 5px;
    border: 1px solid #aaa;
    padding: 0 15px;
    height: 42px;
    margin: 8px 0;
}
.input-field input :focus,
.input-field select:focus{
    box-shadow: 0 3px 6px rgba(0,0,0,0.13);
}
.input-field select,
.input-field input[type="date"]{
    color: #707070;
}
.input-field input[type="date"]:valid{
    color: #333;
}
/* field1 */
form .fields .input-field1{
    display: flex;
    width: calc(100% / 3 - 15px);
    flex-direction: column;
    margin: 4px 0;
}
.input-field1 label{
    font-size: 12px;
    font-weight: 500;
    color: #2e2e2e;
}
.input-field1 input, select{
    outline: none;
    font-size: 14px;
    font-weight: 400;
    color: #333;
    border-radius: 5px;
    border: 1px solid #aaa;
    padding: 0 15px;
    height: 42px;
    margin: 8px 0;
}
.input-field1 input :focus,
.input-field1 select:focus{
    box-shadow: 0 3px 6px rgba(0,0,0,0.13);
}
.input-field1 select,
.input-field1 input[type="date"]{
    color: #707070;
}
.input-field1 input[type="date"]:valid{
    color: #333;
}
/* field1 */
/* field2 */
form .fields .input-field2{
    display: flex;
    width: calc(100% / 2 - 15px);
    flex-direction: column;
    margin: 4px 0;
}
.input-field2 label{
    font-size: 12px;
    font-weight: 500;
    color: #2e2e2e;
}
.input-field2 input, select{
    outline: none;
    font-size: 14px;
    font-weight: 400;
    color: #333;
    border-radius: 5px;
    border: 1px solid #aaa;
    padding: 0 15px;
    height: 42px;
    margin: 8px 0;
}
.input-field2 input :focus,
.input-field2 select:focus{
    box-shadow: 0 3px 6px rgba(0,0,0,0.13);
}
.input-field12 select,
.input-field2 input[type="date"]{
    color: #707070;
}
.input-field2 input[type="date"]:valid{
    color: #333;
}
/* field2 */
.container form button, .backBtn{
    display: flex;
    align-items: center;
    justify-content: center;
    height: 45px;
    width: 100%;
    border: none;
    outline: none;
    color: #fff;
    border-radius: 5px;
    margin: 25px 0;
    background-color: #4070f4;
    transition: all 0.3s linear;
    cursor: pointer;
}
.container form .btnText{
    font-size: 14px;
    font-weight: 400;
}
form button:hover{
    background-color: black;
}
form .buttons{
    display: flex;
    align-items: center;
}
form .buttons button , .backBtn{
    margin-right: 14px;
}

@media (max-width: 750px) {
    .container form{
        overflow-y: scroll;
    }
    .container form::-webkit-scrollbar{
       display: none;
    }
    form .fields .input-field{
        width: calc(100% / 2 - 15px);
    }
}

@media (max-width: 550px) {
    form .fields .input-field{
        width: 100%;
    }
}
</style>
</head>
<body>

    <div class="health-content">
            <div class="container">
                 <h3>View Patient Information Record </h3>

                        <?php
                        if(isset($_GET['id']))
                        {
                            $patient = mysqli_real_escape_string($con, $_GET['id']);
                            $query = "SELECT * FROM infoarchive WHERE id='$patient'";
                            $query_run = mysqli_query($con, $query);

                            if(mysqli_num_rows($query_run) > 0)
                            {
                                $patient = mysqli_fetch_array($query_run);
                                ?>
                            <form action="#" method="POST">
                                <div class="form first">
                                    <div class="details personal">
                                
                                    <div class="fields">
                                        <div class="input-field">
                                        <label>Patient Name</label>
                                        <p class="form-control">
                                            <?=$patient['fname'];?>
                                        </p>
                                    </div>
                                   
                                    <div class="input-field1">
                                        <label>Age</label>
                                        <p class="form-control">
                                            <?=$patient['age'];?>
                                        </p>
                                    </div>
                                    <div class="input-field1">
                                        <label>Date of Birth<i>             (Year-Month-Day)</i></label>
                                        <p class="form-control">
                                            <?=$patient['bday'];?>
                                        </p>
                                    </div>
                                    <div class="input-field1">
                                        <label>Contact No.</label>
                                        <p class="form-control">
                                            <?=$patient['cellno'];?>
                                        </p>
                                    </div>
                                    <div class="input-field2">
                                        <label>Home Address</label>
                                        <p class="form-control">
                                            <?=$patient['homeadd'];?>
                                        </p>
                                    </div>
                                    <div class="input-field2">
                                        <label>Occupation</label>
                                        <p class="form-control">
                                            <?=$patient['occupation'];?>
                                        </p>
                                    </div>
                                    <div class="input-field">
                        <span class="title">Husband Information</span>
                        </div>
                                    <div class="input-field2">
                                        <label>Husband Name</label>
                                        <p class="form-control">
                                            <?=$patient['hname'];?>
                                        </p>
                                    </div>
                                    <div class="input-field2">
                                        <label>hage</label>
                                        <p class="form-control">
                                            <?=$patient['hage'];?>
                                        </p>
                                    </div>
                                    <div class="input-field2">
                                        <label>Date of Birth</label>
                                        <p class="form-control">
                                            <?=$patient['dob'];?>
                                        </p>
                                    </div>
                                    <div class="input-field2">
                                        <label>Occupation</label>
                                        <p class="form-control">
                                            <?=$patient['hoccupation'];?>
                                        </p>
                                    </div>
                                    <div class="input-field2">
                                        <label>Status</label>
                                        <p class="form-control">
                                            <?=$patient['hstatus'];?>
                                        </p>
                                    </div>
                                    <div class="input-field">
                        <span class="title">Obstetric History</span>
                        </div>
                        
                        <div class="input-field3">
                                        <label>obs1</label>
                                        <p class="form-control">
                                            <?=$patient['obs1'];?>
                                        </p>
                                    </div>
                                    <div class="input-field3">
                                        <label>obs2</label>
                                        <p class="form-control">
                                            <?=$patient['obs2'];?>
                                        </p>
                                    </div>
                                    <div class="input-field3">
                                        <label>obs3</label>
                                        <p class="form-control">
                                            <?=$patient['obs3'];?>
                                        </p>
                                        </div>
                                        <div class="input-field3">
                                        <label>obs4</label>
                                        <p class="form-control">
                                            <?=$patient['obs4'];?>
                                        </p>
                                    </div>
                                    <div class="input-field">
                        <span class="title">Medical History</span>
                        </div>
                        <div class="input-field5">
                                        <label>medh1</label>
                                        <p class="form-control">
                                            <?=$patient['medh1'];?>
                                        </p>
                                        </div>
                                        <div class="input-field5">
                                        <label>medh2</label>
                                        <p class="form-control">
                                            <?=$patient['medh2'];?>
                                        </p>
                                        </div>
                                        <div class="input-field5">
                                        <label>medh3</label>
                                        <p class="form-control">
                                            <?=$patient['medh3'];?>
                                        </p>
                                        </div>
                                        <div class="input-field5">
                                        <label>medh4</label>
                                        <p class="form-control">
                                            <?=$patient['medh4'];?>
                                        </p>
                                        </div>
                                        <div class="input-field5">
                                        <label>medh5</label>
                                        <p class="form-control">
                                            <?=$patient['medh5'];?>
                                        </p>
                                        </div>
                                        <div class="input-field5">
                                        <label>medh6</label>
                                        <p class="form-control">
                                            <?=$patient['medh6'];?>
                                        </p>
                                        </div>
                                        <div class="input-field">
                        <span class="title">G P (T__P__A__L__M)</span>
                        </div>
                                        <div class="input-field1">
                                        <label>lmp</label>
                                        <p class="form-control">
                                            <?=$patient['lmp'];?>
                                        </p>
                                        </div>
                                        <div class="input-field1">
                                        <label>edd</label>
                                        <p class="form-control">
                                            <?=$patient['edd'];?>
                                        </p>
                                        </div>
                                        <div class="input-field1">
                                        <label>date</label>
                                        <p class="form-control">
                                            <?=$patient['date'];?>
                                        </p>
                                        </div>
                                        <div class="input-field1">
                                        <label>aog</label>
                                        <p class="form-control">
                                            <?=$patient['aog'];?>
                                        </p>
                                        </div>
                                        <div class="input-field1">
                                        <label>bp</label>
                                        <p class="form-control">
                                            <?=$patient['bp'];?>
                                        </p>
                                        </div>
                                        <div class="input-field1">
                                        <label>wt</label>
                                        <p class="form-control">
                                            <?=$patient['wt'];?>
                                        </p>
                                        </div>
                                        <div class="input-field1">
                                        <label>fh</label>
                                        <p class="form-control">
                                            <?=$patient['fh'];?>
                                        </p>
                                        </div>
                                        <div class="input-field1">
                                        <label>fht</label>
                                        <p class="form-control">
                                            <?=$patient['fht'];?>
                                        </p>
                                        </div>
                                        <div class="input-field1">
                                        <label>loc</label>
                                        <p class="form-control">
                                            <?=$patient['loc'];?>
                                        </p>
                                        </div>
                                        <div class="input-field1">
                                        <label>pres</label>
                                        <p class="form-control">
                                            <?=$patient['pres'];?>
                                        </p>
                                        </div>
                                        <div class="input-field1">
                                        <label>tcb</label>
                                        <p class="form-control">
                                            <?=$patient['tcb'];?>
                                        </p>
                                        </div>
                                        <div class="input-field1">
                                        <label>signature</label>
                                        <p class="form-control">
                                            <?=$patient['signature'];?>
                                        </p>
                                        </div>
                                    </div>
                            </div>
                            <button id="Button" onclick="window.print()" class="btn btn-primary">
                                             Print Record</button>
                                             <a href="infoarchive.php"id="Button" class="btn btn-danger">BACK</a>  
                                        </div>           
                         </form>
                                <?php
                            }
                            else
                            {
                                echo "<h4>No Such Id Found</h4>";
                            }
                        }
                        ?>         
                     </div>
   </div>                   
                        
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>