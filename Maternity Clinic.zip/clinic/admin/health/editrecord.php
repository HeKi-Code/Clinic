<?php
    session_start();
    require '../db/dbcon.php';
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ronquillo Maternity Clinic</title>

    <!-- Box Icons  -->
    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
    <!-- Styles  -->
    <link rel="shortcut icon" href="../assets/img/a.png" type="image/x-icon">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

  .home-section .health-content{
    padding-top: 100px;
  }

.container{
    position: relative;
    max-width: 100%;
    width: 98%;
    border-radius: 6px;
    padding: 30px;
    margin-left: 15px;
    background-color: #fff;
    box-shadow: 0 5px 10px rgba(0,0,0,0.1);
}
.container h3{
    position: relative;
    font-size: 20px;
    font-weight: 600;
    color: #333;
    text-align: center;
    width: calc(100% / 1 - 15px);
}


.container form{
    position: relative;
    margin-top: 16px;
    min-height: 800px;
    background-color: #fff;
    overflow: hidden;
}
.container form .form{
    position: absolute;
    background-color: #fff;
    transition: 0.3s ease;
}
.container form .form.second{
    opacity: 0;
    pointer-events: none;
    transform: translateX(100%);
}
form.secActive .form.second{
    opacity: 1;
    pointer-events: auto;
    transform: translateX(0);
}
form.secActive .form.first{
    opacity: 0;
    pointer-events: none;
    transform: translateX(-100%);
}
.container form .title{
    display: block;
    margin-bottom: 8px;
    font-size: 16px;
    font-weight: 500;
    margin: 6px 0;
    color: #333;
}
.container form .fields{
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
}
form .fields .input-field{
    display: flex;
    width: calc(100% / 1 - 15px);
    flex-direction: column;
    margin: 4px 0;
}
.input-field label{
    font-size: 12px;
    font-weight: 500;
    color: #2e2e2e;
}
.input-field input, select{
    outline: none;
    font-size: 14px;
    font-weight: 400;
    color: #333;
    border-radius: 5px;
    border: 1px solid #aaa;
    padding: 0 15px;
    height: 42px;
    margin: 8px 0;
}
.input-field input :focus,
.input-field select:focus{
    box-shadow: 0 3px 6px rgba(0,0,0,0.13);
}
.input-field select,
.input-field input[type="date"]{
    color: #707070;
}
.input-field input[type="date"]:valid{
    color: #333;
}
/* field1 */
form .fields .input-field1{
    display: flex;
    width: calc(100% / 3 - 15px);
    flex-direction: column;
    margin: 4px 0;
}
.input-field1 label{
    font-size: 12px;
    font-weight: 500;
    color: #2e2e2e;
}
.input-field1 input, select{
    outline: none;
    font-size: 14px;
    font-weight: 400;
    color: #333;
    border-radius: 5px;
    border: 1px solid #aaa;
    padding: 0 15px;
    height: 42px;
    margin: 8px 0;
}
.input-field1 input :focus,
.input-field1 select:focus{
    box-shadow: 0 3px 6px rgba(0,0,0,0.13);
}
.input-field1 select,
.input-field1 input[type="date"]{
    color: #707070;
}
.input-field1 input[type="date"]:valid{
    color: #333;
}
/* field1 */
/* field2 */
form .fields .input-field2{
    display: flex;
    width: calc(100% / 2 - 15px);
    flex-direction: column;
    margin: 4px 0;
}
.input-field2 label{
    font-size: 12px;
    font-weight: 500;
    color: #2e2e2e;
}
.input-field2 input, select{
    outline: none;
    font-size: 14px;
    font-weight: 400;
    color: #333;
    border-radius: 5px;
    border: 1px solid #aaa;
    padding: 0 15px;
    height: 42px;
    margin: 8px 0;
}
.input-field2 input :focus,
.input-field2 select:focus{
    box-shadow: 0 3px 6px rgba(0,0,0,0.13);
}
.input-field12 select,
.input-field2 input[type="date"]{
    color: #707070;
}
.input-field2 input[type="date"]:valid{
    color: #333;
}
/* field2 */
.container form button, .backBtn{
    display: flex;
    align-items: center;
    justify-content: center;
    height: 45px;
    width: 100%;
    border: none;
    outline: none;
    color: #fff;
    border-radius: 5px;
    margin: 25px 0;
    background-color: #4070f4;
    transition: all 0.3s linear;
    cursor: pointer;
}
.container form .btnText{
    font-size: 14px;
    font-weight: 400;
}
form button:hover{
    background-color: #265df2;
}
form .buttons{
    display: flex;
    align-items: center;
}
form .buttons button , .backBtn{
    margin-right: 14px;
}

@media (max-width: 750px) {
    .container form{
        overflow-y: scroll;
    }
    .container form::-webkit-scrollbar{
       display: none;
    }
    form .fields .input-field{
        width: calc(100% / 2 - 15px);
    }
}

@media (max-width: 550px) {
    form .fields .input-field{
        width: 100%;
    }
}
</style>
</head>
<body>
  
          <!-- ============= Home Content =============== -->
        <?php include('../db/message.php'); ?>

        <div class="health-content">
            <div class="container">
                 <h3>Edit Patient Health Record

                            </h3>
                        <?php

                        if(isset($_GET['id']))
                        {
                            $patient_id = mysqli_real_escape_string($con, $_GET['id']);

                            $query = "SELECT * FROM healthrecord WHERE id='$patient_id' ";
                            $query_run = mysqli_query($con, $query);

                            if(mysqli_num_rows($query_run) > 0)
                            {
                                $patient = mysqli_fetch_array($query_run);
                                ?>
                                <form action="../db/code.php" method="POST">
                    <div class="form first">
                        <div class="details personal">
                    
                                    <input type="hidden" name="patient_id" value="<?= $patient['id']; ?>">

                                    <div class="fields">
                                        <div class="input-field">
                                        <label>Patient Name</label>
                                        <input type="text" name="fname" value="<?=$patient['fname'];?>" class="form-control">
                                    </div>
                                    <div class="input-field1">
                                        <label>Date of Birth</label>
                                        <input type="date" name="bday" value="<?=$patient['bday'];?>" class="form-control">
                                    </div>
                                    <div class="input-field1">
                                        <label>Age</label>
                                        <input type="text" name="age" value="<?=$patient['age'];?>" class="form-control">
                                    </div>
                                    <div class="input-field1">
                                        <label>Gender</label>
                                        <input type="text" name="gender" value="<?=$patient['gender'];?>" class="form-control">
                                    </div>
                                    <div class="input-field1">
                                        <label>Height</label>
                                        <input type="text" name="height" value="<?=$patient['height'];?>" class="form-control">
                                    </div>
                                    <div class="input-field1">
                                        <label>Weight</label>
                                        <input type="text" name="weight" value="<?=$patient['weight'];?>" class="form-control">
                                    </div>
                                    <div class="input-field1">
                                        <label>Cellphone No.</label>
                                        <input type="number" name="cellno" value="<?=$patient['cellno'];?>" class="form-control">
                                    </div>
                                    <div class="input-field2">
                                        <label>Occupation</label>
                                        <input type="text" name="occupation" value="<?=$patient['occupation'];?>" class="form-control">
                                    </div>
                                    <div class="input-field2">
                                        <label>Office Address</label>
                                        <input type="text" name="officeadd" value="<?=$patient['officeadd'];?>" class="form-control">
                                    </div>
                                    <div class="input-field2">
                                        <label>Home Address</label>
                                        <input type="text" name="homeadd" value="<?=$patient['homeadd'];?>" class="form-control">
                                    </div>
                                    <div class="input-field2">
                                        <label>Home No.</label>
                                        <input type="text" name="homeno" value="<?=$patient['homeno'];?>" class="form-control">
                                    </div>
                                    <div class="input-field2">
                                        <label>Mother's/Father's Name</label>
                                        <input type="text" name="guardian" value="<?=$patient['guardian'];?>" class="form-control">
                                    </div>
                                    <div class="input-field2">
                                        <label>Cellpone No.</label>
                                        <input type="number" name="gcellno" value="<?=$patient['gcellno'];?>" class="form-control">
                                    </div>
                                    <div class="input-field">
                                        <label>Chief Complaint</label>
                                        <input type="text" name="complaint" value="<?=$patient['complaint'];?>" class="form-control">
                                    </div>
                                    <div class="input-field2">
                                        <label>Attending Physician</label>
                                        <input type="text" name="physician" value="<?=$patient['physician'];?>" class="form-control">
                                    </div>
                                    <div class="input-field2">
                                        <label>Referred By</label>
                                        <input type="text" name="referred" value="<?=$patient['referred'];?>" class="form-control">
                                    </div>
                                 </div>
                            </div>

                                    <div>
                                        <button type="submit" name="update_record" class="btn btn-primary">
                                            Update Patient Health Record
                                        </button>
                                        <a href="recordtable.php"id="Button" class="btn btn-danger">BACK</a>  
                                    </div>

                                </form>
                                <?php
                            }
                            else
                            {
                                echo "<h4>No Such Id Found</h4>";
                            }
                        }
                        ?>
                    </div>
   </div>
 </section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>