<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ronquillo Maternity Clinic</title>

    <!-- Box Icons  -->
    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
    <!-- Styles  -->
    <link rel="shortcut icon" href="../assets/img/a.png" type="image/x-icon">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/form.css">
</head>

<style>
    .container form{
    position: relative;
    margin-top: 16px;
    min-height: 1300px;
    background-color: #fff;
    overflow: hidden;
}


</style>
<body>
<div class="sidebar close">
        <!-- ========== Logo ============  -->
        <a href= "../index.php" class="logo-details">
            <i class='bx bx-clinic'></i>
            <span class="logo_name">Ronquillo Maternity Clinic</span>
        </a>
        <!-- ========== List ============  -->
        <ul class="sidebar-list">
            <!-- -------- Non Dropdown List Item ------- -->
            <li>
                <hr class="sidebar-divider">
                    <div class="title">
                        <a href="../index.php" class="link">
                            <i class='bx bx-grid-alt'></i>
                            <span class="name">Dashboard</span>
                        </a>
                        <!-- <i class='bx bxs-chevron-down'></i> -->
                    </div>
                    <div class="submenu">
                        <a href="../index.php" class="link submenu-title">Dashboard</a>
                            <!-- submenu links here  -->
                    </div>
            </li>
                <hr class="sidebar-divider">
                        <!-- -------- Dropdown List Item ------- -->
                    <li class="dropdown">
                        <div class="title">
                        <a href="#" class="link">
                            <i class='bx bx-user-plus'></i>
                            <span class="name">New Records</span>
                        </a>
                            <i class='bx bxs-chevron-down'></i>
                        </div>
                        <div class="submenu">
                            <a href="#" class="link submenu-title">New Records</a>
                            <a href="../health/addrecord.php" class="link">Health Records</a>
                            <a href="addinfo.php" class="link">Information Records</a>
                        </div>
                    </li>
                <hr class="sidebar-divider">
                        <!-- -------- Dropdown List Item ------- -->
                    <li class="dropdown">
                        <div class="title">
                        <a href="#" class="link">
                            <i class='bx bx-collection'></i>
                            <span class="name">View Records</span>
                        </a>
                            <i class='bx bxs-chevron-down'></i>
                        </div>
                        <div class="submenu">
                            <a href="#" class="link submenu-title">View Records</a>
                            <a href= "../health/recordtable.php" class="link">Health Records</a>
                            <a href="infotable.php" class="link">Information Records</a>
                        </div>
                    </li>
                <hr class="sidebar-divider">
                        <!-- -------- Dropdown List Item ------- -->
                    <li class="dropdown">
                        <div class="title">
                        <a href="#" class="link">
                            <i class='bx bx-user'></i>
                            <span class="name">Staff</span>
                        </a>
                            <i class='bx bxs-chevron-down'></i>
                        </div>
                        <div class="submenu">
                        <a href="#" class="link submenu-title">Staff</a>
                            <a href="../staff/addstaff.php"class="link">Add Staff</a>
                            <a href="../staff/staff.php" class="link">Staff Account</a>
                        </div>
                    </li>   
                    <hr class="sidebar-divider"> 
                    <li class="dropdown">
                        <div class="title">
                        <a href="#" class="link">
                            <i class='bx bx-box'></i>
                            <span class="name">Archive</span>
                        </a>
                            <i class='bx bxs-chevron-down'></i>
                        </div>
                        <div class="submenu">
                        <a href="#" class="link submenu-title">Archive</a>
                        <a href="../archive/healtharchive.php" class="link">Health Record Archives</a>
                        <a href="../archive/infoarchive.php" class="link">Information Archives</a>
                        </div>
                    </li>    
                <hr class="sidebar-divider"> 
                    <!-- -------- Non Dropdown List Item -------
                    <li>
                        <div class="title">
                        <a href="#" class="link">
                            <i class='bx bx-info-circle'></i>
                            <span class="name">About</span>
                        </a>
                        <i class='bx bxs-chevron-down'></i>
                        </div>
                        <div class="submenu">
                            <a href="about.php" class="link submenu-title">About</a>
                            submenu links here 
                         </div>
                    </li> -->

          </ul>
      </div>
    <section class="home-section">
          <!-- ============= Home Section =============== -->
        <nav>
            <div class="sidebar-button">
                <i class='bx bx-menu' ></i>
                <span class="dashboard">Dashboard</span>
            </div>
            <div class="profile-details">
                <img src="../assets/img/a.png" alt="btu">
                <button class="admin_name">ADMIN</button>
                <div class="dropdown-content">
                <a href="../usersetting/user.php">Change Password </a>
                  <a href="../login.php">Logout</a>
                </div>
            </div> 
        </nav>
          <!-- ============= Home Content =============== -->
        <div class="info-content">
            <div class="container">
                 <h3>Add New Patient Information Record</h3>
                 <?php include('../db/message.php'); ?>
        <form action="../db/code.php" method="POST">
            <div class="form first">
                <div class="details personal">
                    <span class="title">Patient Information Records</span>
                    
                    <div class="fields">
                        <div class="input-field">
                            <label>Name</label>
                            <input type="text" name="fname" placeholder="Firstname-Lastname" >
                        </div>
                       
                        <div class="input-field1">
                            <label>Age</label>
                            <input type="text" name="age" placeholder="Enter your age" >
                        </div>

                        <div class="input-field1">
                            <label>Date of Birth</label>
                            <input type="date" name="bday" placeholder="Enter birth date" >
                        </div>
                        
                        <div class="input-field1">
                            <label>Mobile Number</label>
                            <input type="number" name="cellno" placeholder="Enter mobile number" >
                        </div>

                        <div class="input-field2">
                            <label>Home Address</label>
                            <input type="text" name="homeadd" placeholder="Enter your home address"  >
                        </div>

                        <div class="input-field2">
                            <label>Occupation</label>
                            <input type="text" name="occupation" placeholder="occupation" >
                        </div>

                        <div class="input-field2">
                        <span class="title">Husband Information</span>
                        </div>
                        <div class="input-field">
                            <label>Husband Name</label>
                            <input type="text" name="hname" placeholder="Enter husband name" >
                        </div>

                        <div class="input-field2">
                        <label>Age</label>
                            <input type="text" name="hage" placeholder="Enter Husband number" >
                        </div>

                        <div class="input-field2">
                            <label>Date of Birth</label>
                            <input type="date" name="dob" placeholder="Enter birth date" >
                        </div>

                       <div class="input-field2">
                            <label>Occupation</label>
                            <input type="text" name="hoccupation" placeholder="occupation" >
                        </div>

                        <div class="input-field2">
                        <label>Status</label>
                            <input type="text" name="hstatus" placeholder="Status" >
                        </div>

                     <div class="input-field">
                        <span class="title">Obstetric History</span>
                        </div>
                        
                        <div class="input-field3">
                            <label>1st</label>
                            <input type="text" name="obs1" placeholder="First" >
                        </div>

                        <div class="input-field3">
                            <label>2nd</label>
                            <input type="text" name="obs2" placeholder="Second" >
                        </div>

                        <div class="input-field3">
                            <label>3rd</label>
                            <input type="text" name="obs3" placeholder="Third" >
                        </div>

                        <div class="input-field3">
                            <label>4th</label>
                            <input type="text" name="obs4" placeholder="fourth" >
                        </div>

                        <div class="input-field">
                        <span class="title">Medical History <i>(delete what is not needed)</i></span>
                        </div>

                        <div class="input-field5">
                            <label>Hypertension</label>
                            <input type="text" name="medh1" >
                        </div>

                        <div class="input-field5">
                            <label>Diabetic</label>
                            <input type="text" name="medh2">
                        </div>
                        <div class="input-field5">
                            <label>Gioter</label>
                            <input type="text" name="medh3" >
                        </div>
                        <div class="input-field5">
                            <label>Heart Disease</label>
                            <input type="text" name="medh4" >
                        </div>
                        <div class="input-field5">
                            <label>Asthma</label>
                            <input type="text" name="medh5" >
                        </div>
                        <div class="input-field5">
                            <label>Allergy</label>
                            <input type="text" name="medh6">
                        </div>
                        
                <div class="input-field">
                        <span class="title">G P (T__P__A__L__M)</span>
                        </div>

                        <div class="input-field1">
                        <label>LMP</label>
                        <input type="text" name="lmp" placeholder="LMP" >
                        </div>

                        <div class="input-field1">
                        <label>EDD</label>
                        <input type="text" name="edd" placeholder="EDD" >
                        </div>

                        <div class="input-field1">
                        <label>Date</label>
                        <input type="date" name="date"  >
                        </div>

                        <div class="input-field1">
                        <label>AOG</label>
                        <input type="text" name="aog" placeholder="AOG" >
                        </div>

                        <div class="input-field1">
                        <label>BP</label>
                        <input type="text" name="bp" placeholder="BP" >
                        </div>

                        <div class="input-field1">
                        <label>WT</label>
                        <input type="text" name="wt" placeholder="WT" >
                        </div>

                        <div class="input-field1">
                        <label>FH</label>
                        <input type="text" name="fh" placeholder="FH" >
                        </div>

                        <div class="input-field1">
                        <label>FHT</label>
                        <input type="text" name="fht" placeholder="FHT" >
                        </div>

                        <div class="input-field1">
                        <label>LOC</label>
                        <input type="text" name="loc" placeholder="LOC" >
                        </div>

                        <div class="input-field1">
                        <label>PRES</label>
                        <input type="text" name="pres" placeholder="PRES" >
                        </div>

                        <div class="input-field1">
                        <label>TCB</label>
                        <input type="text" name="tcb" placeholder="TCB" >
                        </div>

                        <div class="input-field1">
                        <label>Signature</label>
                        <input type="text" name="signature" placeholder="Signature" >
                        </div>
                    </div>
                </div>

                        <div>
                        <button type="submit" name="save_info" class="btn btn-primary">Save Patient info
                        <i class="uil uil-navigator"></i></button>
                        </div> 
            </div>
        </form>
    </div>
   </div>
 </section>
    <!-- Link JS -->
    </script>
    <script src="../assets/js/main.js"></script>
</body>

</html>
    