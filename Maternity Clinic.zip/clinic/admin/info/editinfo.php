<?php
    session_start();
    require '../db/dbcon.php';
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ronquillo Maternity Clinic</title>

    <!-- Box Icons  -->
    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
    <!-- Styles  -->
    <link rel="shortcut icon" href="../assets/img/a.png" type="image/x-icon">
    <link rel="stylesheet" href="../assets/css/style.css">
        <link rel="stylesheet" href="../assets/css/form.css">

    <style>
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

  .home-section .health-content{
    padding-top: 100px;
  }

.container form{
    position: relative;
    margin-top: 16px;
    min-height: 1300px;
    background-color: #fff;
    overflow: hidden;

}
</style>
</head>
<body>
  
          <!-- ============= Home Content =============== -->
        <?php include('../db/message.php'); ?>

        <div class="health-content">
            <div class="container">
                 <h3>Edit Patient Information Record

                            </h3>
                        <?php

                        if(isset($_GET['id']))
                        {
                            $patient_id = mysqli_real_escape_string($con, $_GET['id']);

                            $query = "SELECT * FROM info WHERE id='$patient_id' ";
                            $query_run = mysqli_query($con, $query);

                            if(mysqli_num_rows($query_run) > 0)
                            {
                                $patient = mysqli_fetch_array($query_run);
                                ?>
                                <form action="../db/code.php" method="POST">
                    <div class="form first">
                        <div class="details personal">
                    
                                    <input type="hidden" name="patient_id" value="<?= $patient['id']; ?>">

                                    <div class="fields">
                                        <div class="input-field">
                                        <label>Patient Name</label>
                                        <input type="text" name="fname" value="<?=$patient['fname'];?>" class="form-control">
                                    </div>
                                    <div class="input-field1">
                                        <label>Age</label>
                                        <input type="text" name="age" value="<?=$patient['age'];?>" class="form-control">
                                    </div>
                                    <div class="input-field1">
                                        <label>Date of Birth</label>
                                        <input type="date" name="bday" value="<?=$patient['bday'];?>" class="form-control">
                                    </div>
                                  
                                    <div class="input-field1">
                                    <label>Contact No.</label>
                                        <input type="number" name="cellno" value="<?=$patient['cellno'];?>" class="form-control">
                                    </div>
                                    <div class="input-field2">
                                    <label>Home Address</label>
                                        <input type="text" name="homeadd" value="<?=$patient['homeadd'];?>" class="form-control">
                                    </div>
                                    <div class="input-field2">
                                    <label>Occupation</label>
                                        <input type="text" name="occupation" value="<?=$patient['occupation'];?>" class="form-control">
                                    </div>
                                    <div class="input-field">
                        <span class="title">Husband Information</span>
                        </div>
                        <div class="input-field2">
                                        <label>Husband Name</label>
                                        <input type="text" name="hname" value="<?=$patient['hname'];?>" class="form-control">
                                    </div>
                                    <div class="input-field2">
                                    <label>Age</label>
                                        <input type="text" name="hage" value="<?=$patient['hage'];?>" class="form-control">
                                    </div>
                                    <div class="input-field2">
                                        <label>Date of Birth</label>
                                        <input type="date" name="dob" value="<?=$patient['dob'];?>" class="form-control">
                                    </div>
                                    <div class="input-field2">
                                        <label>Occupation</label>
                                        <input type="text" name="hoccupation" value="<?=$patient['hoccupation'];?>" class="form-control">
                                    </div>
                                    <div class="input-field2">
                                        <label>Status</label>
                                        <input type="text" name="hstatus" value="<?=$patient['hstatus'];?>" class="form-control">
                                    </div>
                                    <div class="input-field">
                        <span class="title">Obstetric History</span>
                        </div>
                                    <div class="input-field3">
                                        <input type="text" name="obs1" value="<?=$patient['obs1'];?>" class="form-control" placeholder="1st">
                                    </div>
                                    <div class="input-field3">
                                        <input type="text" name="obs2" value="<?=$patient['obs2'];?>" class="form-control" placeholder="2nd">
                                    </div>
                                    <div class="input-field3">
                                        <input type="text" name="obs3" value="<?=$patient['obs3'];?>" class="form-control" placeholder="3rd">
                                    </div>
                                    <div class="input-field3">
                                        <input type="text" name="obs4" value="<?=$patient['obs4'];?>" class="form-control" placeholder="4th">
                                    </div>
                                    
                                    <div class="input-field">
                        <span class="title">Medical History</span>
                        </div>
                                    <div class="input-field5">
                                        <label>Hypertension</label>
                                        <input type="text" name="medh1" value="<?=$patient['medh1'];?>" class="form-control">
                                    </div>
                                    <div class="input-field5">
                                        <label>Diabetic</label>
                                        <input type="text" name="medh2" value="<?=$patient['medh2'];?>" class="form-control">
                                    </div>
                                    <div class="input-field5">
                                        <label>Goiter</label>
                                        <input type="text" name="medh3" value="<?=$patient['medh3'];?>" class="form-control">
                                    </div>
                                    <div class="input-field5">
                                        <label>Hearth Disease</label>
                                        <input type="text" name="medh4" value="<?=$patient['medh4'];?>" class="form-control">
                                    </div>
                                    <div class="input-field5">
                                        <label>Asthma</label>
                                        <input type="text" name="medh5" value="<?=$patient['medh5'];?>" class="form-control">
                                    </div>
                                    <div class="input-field5">
                                        <label>Allergy</label>
                                        <input type="text" name="medh6" value="<?=$patient['medh6'];?>" class="form-control">
                                    </div>

                                    <div class="input-field">
                        <span class="title">G P (T__P__A__L__M)</span>
                        </div>
                                
                                     <div class="input-field1">
                                        <label>lmp</label>
                                        <input type="text" name="lmp" value="<?=$patient['lmp'];?>" class="form-control">
                                     </div>
                                     <div class="input-field1">
                                        <label>edd</label>
                                        <input type="text" name="edd" value="<?=$patient['edd'];?>" class="form-control">
                                     </div>
                                     <div class="input-field1">
                                        <label>date</label>
                                        <input type="date" name="date" value="<?=$patient['date'];?>" class="form-control">
                                     </div>
                                     <div class="input-field1">
                                        <label>aog</label>
                                        <input type="text" name="aog" value="<?=$patient['aog'];?>" class="form-control">
                                     </div>
                                     <div class="input-field1">
                                        <label>bp</label>
                                        <input type="text" name="bp" value="<?=$patient['bp'];?>" class="form-control">
                                     </div>
                                     <div class="input-field1">
                                        <label>wt</label>
                                        <input type="text" name="wt" value="<?=$patient['wt'];?>" class="form-control">
                                     </div>
                                     <div class="input-field1">
                                        <label>fh</label>
                                        <input type="text" name="fh" value="<?=$patient['fh'];?>" class="form-control">
                                     </div>
                                     <div class="input-field1">
                                        <label>fht</label>
                                        <input type="text" name="fht" value="<?=$patient['fht'];?>" class="form-control">
                                     </div>
                                     <div class="input-field1">
                                        <label>loc</label>
                                        <input type="text" name="loc" value="<?=$patient['loc'];?>" class="form-control">
                                     </div>
                                     <div class="input-field1">
                                        <label>pres</label>
                                        <input type="text" name="pres" value="<?=$patient['pres'];?>" class="form-control">
                                     </div>
                                     <div class="input-field1">
                                        <label>tcb</label>
                                        <input type="text" name="tcb" value="<?=$patient['tcb'];?>" class="form-control">
                                     </div>
                                     <div class="input-field1">
                                        <label>signature</label>
                                        <input type="text" name="signature" value="<?=$patient['signature'];?>" class="form-control">
                                     </div>
                                 </div>
                            </div>

                                    <div>
                                        <button type="submit" name="update_info" class="btn btn-primary">
                                            Update Patient Information Record
                                        </button>
                                        <a href="infotable.php" class="btn btn-danger">BACK</a>  
                                    </div>

                                </form>
                                <?php
                            }
                            else
                            {
                                echo "<h4>No Such Id Found</h4>";
                            }
                        }
                        ?>
                    </div>
   </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>