<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ronquillo Maternity Clinic</title>

    <!-- Box Icons  -->
    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
    <!-- Styles  -->
    <link rel="shortcut icon" href="assets/img/a.png" type="image/x-icon">
    <link rel="stylesheet" href="assets/css/style.css">
    
</head>

<body>
<div class="sidebar close">
        <!-- ========== Logo ============  -->
        <a href= "#" class="logo-details">
            <i class='bx bx-clinic'></i>
            <span class="logo_name">Ronquillo Maternity Clinic</span>
        </a>
        <!-- ========== List ============  -->
        <ul class="sidebar-list">
            <!-- -------- Non Dropdown List Item ------- -->
            <li>
                <hr class="sidebar-divider">
                    <div class="title">
                        <a href="index.php" class="link">
                            <i class='bx bx-grid-alt'></i>
                            <span class="name">Dashboard</span>
                        </a>
                        <!-- <i class='bx bxs-chevron-down'></i> -->
                    </div>
                    <div class="submenu">
                        <a href="index.php" class="link submenu-title">Dashboard</a>
                            <!-- submenu links here  -->
                    </div>
            </li>
                <hr class="sidebar-divider">
                        <!-- -------- Dropdown List Item ------- -->
                    <li class="dropdown">
                        <div class="title">
                        <a href="#" class="link">
                            <i class='bx bx-user-plus'></i>
                            <span class="name">New Records</span>
                        </a>
                            <i class='bx bxs-chevron-down'></i>
                        </div>
                        <div class="submenu">
                            <a href="#" class="link submenu-title">New Records</a>
                            <a href="health/addrecord.php" class="link">Health Records</a>
                            <a href="info/addinfo.php" class="link">Information Records</a>
                        </div>
                    </li>
                <hr class="sidebar-divider">
                        <!-- -------- Dropdown List Item ------- -->
                    <li class="dropdown">
                        <div class="title">
                        <a href="#" class="link">
                            <i class='bx bx-collection'></i>
                            <span class="name">View Records</span>
                        </a>
                            <i class='bx bxs-chevron-down'></i>
                        </div>
                        <div class="submenu">
                            <a href="#" class="link submenu-title">View Records</a>
                            <a href= "health/recordtable.php" class="link">Health Records</a>
                            <a href="info/infotable.php" class="link">Information Records</a>
                        </div>
                    </li>
                <hr class="sidebar-divider">
                        <!-- -------- Dropdown List Item ------- -->
                    <li class="dropdown">
                        <div class="title">
                        <a href="#" class="link">
                            <i class='bx bx-user'></i>
                            <span class="name">Staff</span>
                        </a>
                            <i class='bx bxs-chevron-down'></i>
                        </div>
                        <div class="submenu">
                        <a href="#" class="link submenu-title">Staff</a>
                            <a href="staff/addstaff.php"class="link">Add Staff</a>
                            <a href="staff/staff.php" class="link">Staff Account</a>
                        </div>
                    </li>   
                    <hr class="sidebar-divider"> 
                    <li class="dropdown">
                        <div class="title">
                        <a href="#" class="link">
                            <i class='bx bx-box'></i>
                            <span class="name">Archive</span>
                        </a>
                            <i class='bx bxs-chevron-down'></i>
                        </div>
                        <div class="submenu">
                        <a href="#" class="link submenu-title">Archive</a>
                        <a href="archive/healtharchive.php" class="link">Health Record Archives</a>
                        <a href="archive/infoarchive.php" class="link">Information Archives</a>
                        </div>
                    </li>    
                <hr class="sidebar-divider"> 
                    <!-- -------- Non Dropdown List Item -------
                    <li>
                        <div class="title">
                        <a href="#" class="link">
                            <i class='bx bx-info-circle'></i>
                            <span class="name">About</span>
                        </a>
                        <i class='bx bxs-chevron-down'></i>
                        </div>
                        <div class="submenu">
                            <a href="about.php" class="link submenu-title">About</a>
                            submenu links here 
                         </div>
                    </li> -->

          </ul>
      </div>

    <!-- ============= Home Section =============== -->
    <section class="home-section">
        <nav>
            <div class="sidebar-button">
                <i class='bx bx-menu' ></i>
                <span class="dashboard">Dashboard</span>
            </div>
            <div class="profile-details">
                <img src="assets/img/a.png" alt="btu">
                <button class="admin_name">ADMIN</button>
                <div class="dropdown-content">
                  <a href="usersetting/user.php">Change Password </a>
                  <a href="login.php">Logout</a>
                </div>
              </div> 
        </nav>
    
        <!-- home-content -->
        <div class="home-content">
            <div class="overview-boxes">
                <div class="box">
                  <a href="health/recordtable.php">
                    <div class="left-side">
                    <div class="box_topic"> Patient Health Record</div>
                    <div class="indicator">
                        <span class="text">Shortcut to See health record</span>
                    </div>
                </div>   
                </a>
            </div>
            <div class="box">
                <a href="info/infotable.php">
                <div class="left-side">
                <div class="box_topic"> Patient Information Record </div>
                <div class="indicator">
                <span class="text">Shortcut to See Information record</span>
                </div>
            </div>
        </div>
        <div class="box">
                <a href="health/addrecord.php">
                <div class="left-side">
                <div class="box_topic"> Add Health Record </div>
                <div class="indicator">
                    <span class="text">Shortcut to Add health record</span>
                </div>
            </div>
        </div>
        <div class="box">
                <a href="info/addinfo.php">
                <div class="left-side">
                <div class="box_topic"> Add Information Record </div>
                <div class="indicator">
                    <span class="text">Shortcut to Add Information record</span>
                </div>
            </div>
        </div>
        </div>
    </div>
</div>
</div>

    </div>
    
    </section>
    <!-- Link JS -->
    <script src="assets/js/main.js"></script>
</body>

</html>