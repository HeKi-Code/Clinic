<!DOCTYPE html>
<html lang= "en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/login.css">
    <title>Clinic Management System </title>
</head>
<style>
body
  {
  background-image: url('assets/img/b.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;
  }
</style>
  <div class="login-container">
  <h1>Login to your account</h1>

  <br/>
  <div class="form-logo">
      <img src="assets/img/a.png" alt="" height="200" width="200">
  </div>
  <form action="index.php" method="post">
    <div class="form-element">
      
        <input type="text" name="username" id="username" placeholder="Username" required>
      </div>
<br> 
      <div class="form-element">
        <input type="password" name="password" id="password" placeholder="Password" required>
      </div>
  <button type="submit" name="login">Login</button>
</form>

</div>

</body>
</html>