<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ronquillo Maternity Clinic</title>

    <!-- Box Icons  -->
    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
    <!-- Styles  -->
    <link rel="shortcut icon" href="../assets/img/a.png" type="image/x-icon">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/form.css">
</head>
<style>
    .container form{
    position: relative;
    margin-top: 16px;
    min-height: 900px;
    background-color: #fff;
    overflow: hidden;
}
</style>
<body>
<div class="sidebar close">
        <!-- ========== Logo ============  -->
        <a href= "#" class="logo-details">
            <i class='bx bx-clinic'></i>
            <span class="logo_name">Ronquillo Maternity Clinic</span>
        </a>
        <!-- ========== List ============  -->
        <ul class="sidebar-list">
            <!-- -------- Non Dropdown List Item ------- -->
            <li>
                <hr class="sidebar-divider">
                    <div class="title">
                        <a href="../index.php" class="link">
                            <i class='bx bx-grid-alt'></i>
                            <span class="name">Dashboard</span>
                        </a>
                        <!-- <i class='bx bxs-chevron-down'></i> -->
                    </div>
                    <div class="submenu">
                        <a href="../index.php" class="link submenu-title">Dashboard</a>
                            <!-- submenu links here  -->
                    </div>
            </li>
                <hr class="sidebar-divider">
                        <!-- -------- Dropdown List Item ------- -->
                    <li class="dropdown">
                        <div class="title">
                        <a href="#" class="link">
                            <i class='bx bx-user-plus'></i>
                            <span class="name">New Records</span>
                        </a>
                            <i class='bx bxs-chevron-down'></i>
                        </div>
                        <div class="submenu">
                            <a href="#" class="link submenu-title">New Records</a>
                            <a href="addrecord.php" class="link">Health Records</a>
                            <a href="../info/addinfo.php" class="link">Information Records</a>
                        </div>
                    </li>
                <hr class="sidebar-divider">
                        <!-- -------- Dropdown List Item ------- -->
                    <li class="dropdown">
                        <div class="title">
                        <a href="#" class="link">
                            <i class='bx bx-collection'></i>
                            <span class="name">View Records</span>
                        </a>
                            <i class='bx bxs-chevron-down'></i>
                        </div>
                        <div class="submenu">
                            <a href="#" class="link submenu-title">View Records</a>
                            <a href= "recordtable.php" class="link">Health Records</a>
                            <a href="../info/infotable.php" class="link">Information Records</a>
                        </div>
                    </li>
              
                    <hr class="sidebar-divider"> 
                    
                    <!-- -------- Non Dropdown List Item -------
                    <li>
                        <div class="title">
                        <a href="#" class="link">
                            <i class='bx bx-info-circle'></i>
                            <span class="name">About</span>
                        </a>
                        <i class='bx bxs-chevron-down'></i>
                        </div>
                        <div class="submenu">
                            <a href="about.php" class="link submenu-title">About</a>
                            submenu links here 
                         </div>
                    </li> -->

          </ul>
      </div>


    <section class="home-section">
          <!-- ============= Home Section =============== -->
        <nav>
            <div class="sidebar-button">
                <i class='bx bx-menu' ></i>
                <span class="dashboard">Dashboard</span>
            </div>
            <div class="profile-details">
                <img src="../assets/img/a.png" alt="btu">
                <button class="admin_name">User</button>
                <div class="dropdown-content">
                <a href="../usersetting/user.php">Change Password </a>
                  <a href="../login.php">Logout</a>
                </div>
            </div> 
        </nav>
          <!-- ============= Home Content =============== -->
        <div class="health-content">
            <div class="container">
           
                 <h3>Add New Patient Health Record</h3>
                 <?php include('../db/message.php'); ?>
        <form action="../db/code.php" method="POST">
            <div class="form first">
                <div class="details personal">
                    <span class="title">Patient Health Records</span>

                    <div class="fields">
                        <div class="input-field">
                            <label>Name</label>
                            <input type="text" name="fname" placeholder="Firstname-Lastname" required>
                        </div>

                        <div class="input-field1">
                            <label>Date of Birth</label>
                            <input type="date" name="bday" placeholder="Enter birth date"required>
                        </div>

                        <div class="input-field1">
                            <label>Age</label>
                            <input type="text" name="age" placeholder="Enter your age" required>
                        </div>

                        <div class="input-field1">
                            <label>Gender</label>
                            <input type="text" name="gender" placeholder="Enter your gender"required>
                        </div>
                        
                        <div class="input-field1">
                            <label>Height </label>
                            <input type="text" name="height"placeholder="Height in cm" >
                        </div>

                        <div class="input-field1">
                            <label>Weight </label>
                            <input type="text" name="weight"placeholder="Weight in kg" >
                        </div>
                        <div class="input-field1">
                            <label>Mobile Number</label>
                            <input type="number" name="cellno" placeholder="Enter mobile number" required>
                        </div>

                      
                        <div class="input-field2">
                            <label>Occupation</label>
                            <input type="text" name="occupation"placeholder="Enter your occupation" required>
                        </div>

                        <div class="input-field2">
                            <label>Office Address/No.</label>
                            <input type="text" name="officeadd" placeholder="Enter office address/no." >
                        </div>

                        <div class="input-field2">
                            <label>Home Address</label>
                            <input type="text" name="homeadd" placeholder="Enter your home address"  required>
                        </div>

                        <div class="input-field2">
                            <label>Home No.</label>
                            <input type="text" name="homeno"placeholder="Enter home no." >
                        </div>

                        <div class="input-field2">
                            <label>Mother's/Father's Name</label>
                            <input type="text" name="guardian" placeholder="Enter mother's/father's name" required>
                        </div>

                        <div class="input-field2">
                        <label>Mobile Number</label>
                            <input type="number" name="gcellno" placeholder="Enter mobile number" required>
                        </div>

                        <div class="input-field">
                        <label>Chief Complaints</label>
                            <input type="text" name="complaint"placeholder="Enter complaint" required>
                        </div>

                        <div class="input-field2">
                            <label>Attending Physician</label>
                            <input type="text" name="physician" placeholder="Attending physician name" required>
                        </div>

                        <div class="input-field2">
                        <label>Referred By</label>
                            <input type="text" name="referred" placeholder="Referred by" required>
                        </div>

                        <div class="input-field1">
                            <label>Date</label>
                            <input type="date" name="date" required >
                        </div>

                        <div class="input-field1">
                        <label>History/Findings/Physical Examinations</label>
                            <input type="text" name="exam" placeholder="History/Findings/Physical Examinations"  required>
                        </div>

                        <div class="input-field1">
                        <label>Physician's Notes/Direction</label>
                            <input type="text" name="notes" placeholder="Physician's Notes/Direction" required>
                        </div>
                    </div>
                </div>
                        <div>
                        <button type="submit" name="save_record" class="btn btn-primary">Save Health Record
                        <i class="uil uil-navigator"></i></button>
                        </div> 
            </div>
        </form>
    </div>
   </div>
 </section>
    <!-- Link JS -->
    </script>
    <script src="../assets/js/main.js"></script>
</body>

</html>
    