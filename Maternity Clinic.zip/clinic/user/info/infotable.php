<?php
    session_start();
    require '../db/dbcon.php';
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="shortcut icon" href="../assets/img/a.png" type="image/x-icon">
    <link rel="shortcut icon" href="assets/img/a.png" type="image/x-icon">

    <title>Ronquillo Maternity Clinic</title>
    <style>
        body{
            background-color: yellowgreen;
        }
        .h4, h4 {
    text-align: center;
    }
    .btn-primary {
    background-color: yellowgreen;
    border-color:rgb(76, 104, 20);
}
.btn-primary:hover {
    background-color: rgb(76, 104, 20);
}

td, th{
    text-align:center;
}
    </style>
</head>
<body>
  
    <div class="container mt-4">

        <?php include('../db/message.php'); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Patient Information Record
                            <a href="addinfo.php" class="btn btn-primary float-end">Add Patient Information</a></br></br>
                            <a href="../index.php" class="btn btn-primary float-end">Go back to Main</a>
                        </h4>
                    </div>
                    <div class="card-body">

                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Patient Name</th>
                                    <th>Husband Name</th>
                                    <th>Patient Mobile No.</th>
                                    <th>Date</th>


                                </tr>
                            </thead>
                            <tbody>
                            <?php 
                                    $query = "SELECT * FROM info ORDER BY id DESC";
                                    $query_run = mysqli_query($con, $query);

                                    if(mysqli_num_rows($query_run) > 0)
                                    {
                                        foreach($query_run as $patient)
                                        {
                                            ?>
                                            <tr>
                                                <td><?= $patient['fname']; ?></td>
                                                <td><?= $patient['hname']; ?></td>
                                                <td><?= $patient['cellno']; ?></td>
                                                <td><?= $patient['date']; ?></td>
                                                <td>
                                                    <a href="viewinfo.php?id=<?= $patient['id']; ?>" class="btn btn-info btn-sm">View</a>
                                                    <a href="editinfo.php?id=<?= $patient['id']; ?>" class="btn btn-success btn-sm">Edit</a>
                                                    
                                                </td>
                                            </tr>
                                            <?php
                                        }
                                    }
                                    else
                                    {
                                        echo "<h5> No Record Found </h5>";
                                    }
                                ?>
                                
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>